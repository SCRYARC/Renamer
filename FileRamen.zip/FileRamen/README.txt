
GoTo:
	dist -> fileRamenWin -> fileRamenWin.exe

There is a possibility that windows antivirus will catch it, make an exception to it in the antivirus

The source code is also posted to the Github